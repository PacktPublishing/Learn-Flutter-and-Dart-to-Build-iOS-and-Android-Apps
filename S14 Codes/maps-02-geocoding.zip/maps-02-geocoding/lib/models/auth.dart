enum AuthMode {
  Signup,
  Login
}